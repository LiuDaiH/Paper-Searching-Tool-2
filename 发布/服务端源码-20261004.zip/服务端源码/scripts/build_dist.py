"""服务端源码打包 —— 打 `发布/服务端源码-<日期>.zip`（可重复）。

内容：核心源码（hotspot/、scripts/）+ config.yaml + requirements.txt +
入口/说明文档。排除：workspace（数据产物，可重建）、日志、.git、.zhanlu、
__pycache__、*.pyc、.playwright-mcp、debug.log、临时测试脚本。
"""

from __future__ import annotations

import datetime
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DIST_DIR = ROOT / "发布"

# 顶层条目（目录走整树拷贝，但排除其中不良子目录/文件后缀）
ITEMS = [
    "hotspot", "scripts",
    "config.yaml", "requirements.txt",
    "README.md", "AGENTS.md",
    "热点挖掘系统-方案设计.md",
    "测试计划-大创接入评测.md",
    "规划-接入arXiv周报与发布.md",
    "规划-周报接入大创算法.md",
]
EXCLUDE_DIRS = {"__pycache__", ".git", ".zhanlu", ".playwright-mcp", "workspace", "日志", "发布", "eval"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".log"}

RUN_GUIDE = """# 运行说明（服务端）

## 1. 启动
```bash
pip install -r requirements.txt
streamlit run scripts/run_ui.py --server.port 8502
```
浏览器打开 http://127.0.0.1:8502 ，左侧切换「会议 24+25 / arXiv 周报」数据源。

## 2. 外部依赖（不在源码包内，需自行就位）
- **dasc**：D:\\大学编程学习\\obsidian\\dasc（sys.path 接线见 hotspot/__init__.py）
- **md2vectors**：库根 工具/（embedding）
- **语料**：G 盘 24+25 会议 papers.jsonl + arXiv 周报 数据/papers.jsonl（config.corpus.*）
- **API key**：环境变量（llm.api_key_env / llm_eval.api_key_env / apis.api_key_env），永不落盘

## 3. 每周增量（周报）
```bash
python scripts/update_arxiv_weekly.py --init   # 首次（跳过历史，建水位）
python scripts/update_arxiv_weekly.py          # 之后每周（只处理新增，幂等）
```
> 亦可用 `automation`/cron 定时自动跑。

## 4. 说明
- workspace/ 数据产物可全量重建，不入包。
- 本包为「服务端（引擎+UI）」源码交付；客户端是浏览器，无需单独打包。
"""


def _iter_files(src: Path):
    """递归产出一致相对路径文件序列（排除 DIR/后缀/文件）。"""
    for p in sorted(src.rglob("*")):
        rel = p.relative_to(ROOT).as_posix()
        if any(part in EXCLUDE_DIRS for part in p.parts):
            continue
        if p.suffix.lower() in EXCLUDE_SUFFIXES or p.name in {"debug.log"}:
            continue
        if p.is_dir():
            continue
        yield rel


def build() -> Path:
    DIST_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.date.today().strftime("%Y%m%d")
    out = DIST_DIR / f"服务端源码-{stamp}.zip"
    top = "服务端源码"
    count = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel in _iter_files(ROOT):
            if rel.startswith("每日") or rel.startswith("日志"):
                continue
            # 只取白名单顶层项
            if rel.split("/", 1)[0] not in ITEMS and rel not in ITEMS:
                continue
            zf.write(ROOT / rel, f"{top}/{rel}")
            count += 1
        zf.writestr(f"{top}/运行说明.md", RUN_GUIDE)
        count += 1
    print(f"✅ 服务端源码包 → {out}（{count} 个文件，{out.stat().st_size/1024:.0f} KB）")
    return out


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="服务端源码打包")
    ap.parse_args()
    build()
