---
tags: [索引]
---

# hotspot/reasoning · `_index`（L5 推理层）

## 1. 这个文件夹是什么

L5 推理层：带引用生成答案 + 引用校验（防幻觉最后防线）。

## 2. 当前工作状态

- 代码 ✅ 已写（parse/classify 单测通过，裸 id 约定一致）
- 端到端 ⏸ 待 LLM key + 数据

## 3. 文件清单

**计划文件**：无（全部是代码）。
**数据文件**：无。

## 脚本速查

- `answer.py` —— L5 带引用生成答案（强制 `[P:id]` / `[C:id]`）。
- `verify.py` —— L5 引用校验：missing_id / unsupported 分开判，防幻觉。

（`__init__.py` 是包脚手架，不单独登记。）

## 4. 建议阅读顺序

1. `verify.py`（防幻觉关键）

## 5. 相关

- 上位指针：`hotspot/_index.md`
- 口径：`热点挖掘系统-方案设计.md` §3.5
